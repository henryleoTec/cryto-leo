$(document).ready(function(){
    $(".set1").hover(function(){
        $(".set-list").toggle()
    })
    $(".set-list").hover(function(){
        $(".set-list").toggle()
    })

    
    $(".set-list1").hover(function(){
        $(".set-list1").toggle()
    })

    $(".set3").hover(function(){
        $(".set-list2").toggle()
    })
    $(".set-list2").hover(function(){
        $(".set-list2").toggle()
    })
    $(".set4").hover(function(){
        $(".set-list3").toggle()
    })
    $(".set-list3").hover(function(){
        $(".set-list3").toggle()
    })

    $(".set5").hover(function(){
        $(".set-list4").toggle()
    })
    $(".set-list4").hover(function(){
        $(".set-list4").toggle()
    })

    $(".set6").hover(function(){
        $(".set-list5").toggle()
    })
    $(".set-list5").hover(function(){
        $(".set-list5").toggle()
    })

    $(".set7").hover(function(){
        $(".set-list6").toggle()
    })
    $(".set-list6").hover(function(){
        $(".set-list6").toggle()
    })
})
$(".side-bar-set").click(function(){
        $(".side-bar").toggleClass("activei")
    })
$("#set-top .owl-carousel").owlCarousel({
    loop:true,
    nav:true,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:3,
            nav:false
        },
        1000:{
            items:3,
            nav:true,
            loop:false
        }
    }

})
$("#set-al-top .owl-carousel").owlCarousel({
    loop:true,
    nav:true,
    dots:false,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:3,
            nav:false
        },
        1000:{
            items:3,
            nav:true,
            loop:false
        }
    }

})